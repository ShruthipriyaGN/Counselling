<html>
<head>
<title>counseling</title>
</head>
<body bgcolor=#efe4b0>
<center>
<img src="images/logo1.jpg" width=80%>
<br>
<br>
<img src="images/welcome.gif">
<br>
<font size=8 color="green" face="Algerian">
College Counseling Management System
<pre>
<a href="prgm1.php"><img src="images/af.jpg"><br>
<a href="prgm2.php"><img src="images/al.jpg"><br>
<a href="prgm3.php"><img src="images/sl.jpg">
</pre>
</center>	
</body>
</html>