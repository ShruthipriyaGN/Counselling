<?php
$mark=$_POST['mark'];
echo$mark;
if($mark>="75"&&$mark<=200)
{
?>
<script language="javascript">
window.location="data.php";
</script>
<?
}
else
{
?>
<script language="javascript">
alert("you are eligible");
window.location ="prgm1.php";
</script>
<?
}
?>
<?php
$phy=$_POST['phy'];
$che=$_POST['che'];
$mat=$_POST['mat'];
$cs=$_POST['cs'];
//echo"$phy $che $mat $cs";
if($phy>="75"&&$phy<="200"&&$che>="75"&&$che<="200"&&$mat>="75"&&$mat<="200"&&$cs>="75"&&$cs<="200")
{
?>
<script language="javascript">
window.location="data.php";
</script>
<?
}
else
{
?>
<script language="javascript">
alert("you are not eligible");
window.location ="prgm1.php";
</script>
<?
}
?>