<html>
<head>
<title>counseling</title>
</head>
<body bgcolor=gray>
<center>
<pre>

<img src="images/logo1.jpg" width=80%>
<font size=8 color="yellow" face="Algerian">
ADMIN LOGIN

<a href="view.php"><img src="images/view.jpg">
<a href="general.php"><img src="images/general.jpg">
<a href="ph.php"><img src="images/ph.jpg">
<a href="ex.php"><img src="images/ex.jpg">
<a href="sports.php"><img src="images/sports.jpg">
<a href="seat1.php"><img src="images/stu.jpg">
<a href="prgm.php">BACK</a>
</pre>
</center>
</body>
</html>