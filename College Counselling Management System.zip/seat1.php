<html>
<head>
<script>
function validateR()
{
var selectedCombobox=(f5.department.value);
if(selectedCombobox=="s1")
{
alert("please select the department");
return false;
}
return true;
}
</script>
</head>
<?php
require("head.php");?>

<body bgcolor="lightblue">
<center>
<pre>
<form name="f5" action="seat2.php" method="post">

<font size=5 color=black  face="Lucida Calligraphy">Department&nbsp:<select name="department" required><option value="s1">Select</option>
<option value="a">ECE</option>
<option value="c">EEE</option>
<option value="d">CSE</option>
<option value="e">MECH</option>
</select>
<input type="submit" name="submit"  value="SUBMIT" onclick="return validateR();">
<br>
<a href="prgm.php">BACK</a></pre>

</form></center>
</body>
</html>
