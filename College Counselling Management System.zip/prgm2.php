<html>
<head>
<script>
function check()
{
if(document.f1.name1.value=="")
{
alert("please enter the username");
document.f1.name1.focus();
return false;
}
if(document.f1.name2.value=="")
{
alert("please enter the password");
document.f1.name2.focus();
return false;
}
return true();
}
</script>
<title>counseling</title>
</head>
<title>counseling</title>
</head>
<body bgcolor=#00bfff>
<center>
<img src="images/logo.jpg" width=80%>
<br>
<br>
<br>
<form name="f1"action="verify.php"method="post" onsubmit="return check()"> 
<pre>
<font size=5 color="yellow" face="Times New Roman"style="bold">
Username &nbsp;&nbsp;&nbsp;&nbsp:<input type="text"name="name1">
<br><br>
Password &nbsp;&nbsp;&nbsp;&nbsp;:<input type="password"name="name2">
<br>
<input type="submit"name="submit"value="LOGIN">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="submit"name="submit1"value="RESET">
</font>
</pre>
<br>
<a href="prgm.php"><img src="images/home1.jpg">
</form>
</center>
</body>
</html>