<html>
<head>
<title>counseling</title>
</head>
<body bgcolor=#00bfff>
<center>
<td><img src="images/logo1.jpg" width=80%>
<br>
<br>
<br>
<form name="f3" action="verify1.php" method="post">
<pre>
<font size=5 color="yellow" face="Times New Roman" style="bold">
Register No. &nbsp;&nbsp;&nbsp;&nbsp;   :<input type="number"name="n3" required>
<br>
Date of Birth &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<input type="password"name="n4" required>
<br>
<input type="submit"name="submit"value="LOGIN">
</font>
</pre>
<br>
<br>
<a href="prgm.php"><img src="images/home1.jpg">
</form>
</center>
</body>
</html>