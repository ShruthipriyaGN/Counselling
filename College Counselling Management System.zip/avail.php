<html>
<head>
<script>
function validateR()
{
var selectedCombobox=(f4.department.value);
if(selectedCombobox=="1")
{
alert("please select the department");
return false;
}
return true;
}
</script>
</head>

<?php
$reg=$_REQUEST[id];
//echo $reg;

require("head.php");
require("connect.php");
$res=mysql_query("select * from colg1 where regno='$reg'");
while($row=mysql_fetch_array($res))
{
$regno=$row["regno"];
$name=$row["name"];
$gender=$row["gen"];
$community=$row["community"];
}
?>
<html>

<body bgcolor="lightblue">
<center>
<pre>
<form name="f4" action="postavail.php" method="post">
<table width="80%" border=2>
<tr><td width=50%><font size=5 color=black  face="Lucida Calligraphy">Regno.
<td width=50%><input type="text" name="regno" value=<?php echo$regno?>>  </tr>
<tr><td width=50%><font size=5 color=black  face="Lucida Calligraphy">Name
<td width=50%><input type="text" name="name" value=<?php echo$name?>>  </tr>
<tr><td width=50%><font size=5 color=black  face="Lucida Calligraphy">Gender
<td width=50%><input type="text" name="gender" value=<?php echo$gender?>> </tr>
<tr><td width=50%><font size=5 color=black  face="Lucida Calligraphy">Community
<td width=50%><input type="text" name="community" value=<?php echo$community?>>  </tr>
<tr>
<td width=50%><font size=5 color=black  face="Lucida Calligraphy">Department
<td><font size=5 color=black  face="Lucida Calligraphy"> <select name="department" value=<?php echo$department?>><option value="1">Select</option>
<option>ECE</option>
<option>EEE</option>
<option>CSE</option>
<option>MECH</option>
</select>	
</tr></table>
<input type="submit" name="submit"  value="SUBMIT"  onclick="return validateR();">
<a href="prgm.php">BACK</a></pre>
</form></center>
</body>
</html>
