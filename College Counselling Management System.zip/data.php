

<?php
$mark=$_POST['mark'];
$department=$_POST['type'];
$moi=$_POST['type1'];
$name=$_POST['name'];
$gen=$_POST['gen'];
$dob=$_POST['date'];
$community=$_POST['type2'];
$nationality=$_POST['national'];
$religion=$_POST['religion'];
$state=$_POST['type3'];
$fmg=$_POST['fmg'];
$ai=$_POST['ai'];
$ph=$_POST['ph'];
$ex=$_POST['ex'];
$ani=$_POST['ani'];
$snn=$_POST['snn'];
$address=$_POST['add'];
$phy=$_POST['phy'];
$che=$_POST['che'];
$mat=$_POST['mat'];
$cs=$_POST['cs'];
//echo "$mark $department $moi $name $gen $dob $community  $nationality  $religion $state $fmg $ai $ph $ex $ani $snn $address $phy $che $mat $cs ";
$con=mysql_connect("localhost","root","");
if(!$con)
{
echo ("could not connect db");
}
mysql_select_db("shru",$con);

$s=1001;
$res=mysql_query("select * from colg");
while($row=mysql_fetch_array($res))
{
$regno=$row["regno"];
$s++;
}


mysql_query("insert into colg(regno,mark,department,moi,name,gen,dob,community,nationality,religion,state,fmg,ai,ph,ex,ani,snn,address,phy,che,mat,cs)values('$s','$mark','$department', '$moi', '$name', '$gen', '$dob', '$community', ' $nationality', '$religion', '$state', '$fmg','$ai','$ph','$ex','$ani','$snn','$address','$phy', '$che', '$mat', '$cs')");




mysql_query("insert into colg1(regno,mark,department,moi,name,gen,dob,community,nationality,religion,state,fmg,ai,ph,ex,ani,snn,address,phy,che,mat,cs)values('$s','$mark','$department', '$moi', '$name', '$gen', '$dob', '$community', ' $nationality', '$religion', '$state', '$fmg','$ai','$ph', '$ex', '$ani', '$snn','$address', '$phy', '$che', '$mat', '$cs')");
?>
<?php
require("head.php");
?>
<body bgcolor="lightblue">
<center>
<pre>
<font size=8 color="yellow" face="Algerian">YOUR APPLICATION IS SUBMITTED SUCESSFULLY<BR>
<font size=5 color="BROWN" face="Microsoft Sans Serif">Your reg no:   <? echo "$s"; ?><br>
<a href="prgm1.php">NEXT APPLICATION</a><br>
<a href="prgm.php">BACK</a>
</center>
</pre>
</html>






