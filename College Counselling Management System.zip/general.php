
<?php
require("head.php");

?>
<body bgcolor="lightblue">
<center>
<table width="80%" border=2>
<tr bgcolor=lightblue>
<TH><font size=5 color="brown" face="Times New Roman">REGISTER NO.
<th><font size=5 color="brown" face="Times New Roman">NAME
<TH><font size=5 color="brown" face="Times New Roman">MARK SECURED OUT OF 1200
<TH><font size=5 color="brown" face="Times New Roman">DOB
<TH><font size=5 color="brown" face="Times New Roman">DEPARTMENT
<TH><font size=5 color="brown" face="Times New Roman">GENDER
<TH><font size=5 color="brown" face="Times New Roman">STATE
<TH><font size=5 color="brown" face="Times New Roman">PHYSICALLY HANDICAPPED
<TH><font size=5 color="brown" face="Times New Roman">EX-SERVICEMAN

<TH><font size=5 color="brown" face="Times New Roman">SPORTS/NCC/NSS


</tr>
<tr>
<?
require("connect.php");
$res=mysql_query("select * from colg ORDER BY mark DESC");
while($row=mysql_fetch_array($res))
{
$regno=$row["regno"];
$name=$row["name"];
$mark=$row["mark"];
$dob=$row["dob"];
$department=$row["department"];
$gen=$row["gen"];
$state=$row["state"];
$ph=$row["ph"];
$ex=$row["ex"];
$snn=$row["snn"];

echo "<tr><td>$regno<td>$name<td>$mark<td>$dob<td>$department<td>$gen<td>$state<td>$ph<td>$ex<td>$snn</tr>";
}
?>
</tr>
</table>
<pre><font size=8 color="yellow" face="Algerian">
<a href="admin.php">BACK</a></pre>
</center>
</body>
</html>














