<?php
session_start();
$regno=$_POST['n3'];
$dob=$_POST['n4'];

//echo "$regno $dob";
require("connect.php");

$_SESSION['id'] = $regno;

echo $_SESSION['id'];


$res=mysql_query("select * from colg where regno='$regno'");
while($row=mysql_fetch_array($res))
{
$regno1=$row["regno"];
$name1=$row["name"];
$dob1=$row["dob"];
}
if($regno==$regno1&& $dob==$dob1)
{
?>
<script language="javascript">
window.location="sview.php";
</script>
<?
}
else if($regno==" " && $dob==" ")
{
echo"$regno $dob";
?>
<script language="javascript">
alert("incorrect regno. or dob");
window.location="sview.php";
</script>
<?
}
else 
{
?>
<script language="javascript">
alert("incorrect regno. or dob");
window.location ="prgm3.php";
</script>
<?
}
?>