<?php
require("head.php");

?><html>
<body bgcolor="lightblue">
<center>
<table width="80%" border=2>
<tr bgcolor=lightblue>
<TH><font size=5 color="brown" face="Times New Roman">REGISTER NO.
<th><font size=5 color="brown" face="Times New Roman">NAME
<TH><font size=5 color="brown" face="Times New Roman">MARK SECURED OUT OF 1200
<TH><font size=5 color="brown" face="Times New Roman">DOB
<TH><font size=5 color="brown" face="Times New Roman">DEPARTMENT
<TH><font size=5 color="brown" face="Times New Roman">COMMUNITY
<TH><font size=5 color="brown" face="Times New Roman">STATE
</tr>
<tr>
<?
require("connect.php");
$res=mysql_query("select * from colg where ph='yes' ORDER BY mark DESC");
while($row=mysql_fetch_array($res))
{
$regno=$row["regno"];
$name=$row["name"];
$mark=$row["mark"];
$dob=$row["dob"];
$department=$row["department"];
$community=$row["community"];
$state=$row["state"];
echo "<tr><td>$regno<td>$name<td>$mark<td>$dob<TD>$department<td>$community<td>$state</tr>";
}
?>
</tr>
</table>
<pre><font size=8 color="yellow" face="Algerian">
<a href="admin.php">BACK</a></pre>
</center>
</body>
</html>











