<?php
require("head.php");

?>
<body bgcolor="lightblue">
<center>
<table width="80%" border=2>
<tr bgcolor=lightblue>
<TH><font size=5 color="brown" face="Old English Text MT">REGISTER NO.
<th><font size=5 color="brown" face="Old English Text MT">NAME
<TH><font size=5 color="brown" face="Old English Text MT">MARK SECURED OUT OF 1200
<TH><font size=5 color="brown" face="Old English Text MT">DOB
<TH><font size=5 color="brown" face="Old English Text MT">DEPARTMENT
<TH><font size=5 color="brown" face="Old English Text MT">COMMUNITY
<TH><font size=5 color="brown" face="Old English Text MT">STATE
</tr>
<tr>
<?
require("connect.php");
$res=mysql_query("select * from colg where ex='yes'ORDER BY mark DESC");
while($row=mysql_fetch_array($res))
{
$regno=$row["regno"];
$name=$row["name"];
$mark=$row["mark"];
$dob=$row["dob"];
$department=$row["department"];
$community=$row["community"];
$state=$row["state"];

echo "<tr><td>$regno<td>$name<td>$mark<td>$dob<TD>$department<td>$community<td>$state</tr>";

}
?>
</tr>
</table>
<pre><font size=8 color="yellow" face="Algerian">
<a href="admin.php">BACK</a></pre>
</center>
</body>
</html>











