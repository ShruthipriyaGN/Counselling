<?php
$con=mysql_connect("localhost","root","");
if(!$con)
{
echo ("could not connect db");
}
mysql_select_db("shru",$con);
?>