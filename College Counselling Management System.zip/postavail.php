<?php

$regno = $_POST['regno'];
$name = $_POST['name'];
$gender = $_POST['gender'];
$community = $_POST['community'];
$department = $_POST['department'];
require("head.php");
require("connect.php");

mysql_query("insert into seat(regno,name,gender,community,department)values('$regno','$name','$gender','$community','$department')");


mysql_query("delete from colg1 where regno='$regno'");

?>

<body bgcolor="lightblue">
<center>
<pre>
<font size=8 color="yellow" face="Algerian">YOUR COURSE ALLOCATED SUCESSFULLY<BR>
<font size=5 color="BROWN" face="Microsoft Sans Serif">Student Register Number:   <? echo "$regno"; ?><br>
<a href="view.php">NEXT ALLOTEMENT</a><br>

</center>
</pre>
</html>






