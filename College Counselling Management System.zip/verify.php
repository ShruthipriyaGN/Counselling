<?php
$name=$_POST['name1'];
$pass=$_POST['name2'];
//echo"$name $pass";
if($name=="saec"&& $pass=="sp")
{
?>
<script language="javascript">
window.location="admin.php";
</script>
<?
}
else
{
?>
<script language="javascript">
alert("incorrect password or username");
window.location ="prgm2.php";
</script>
<?
}
?>