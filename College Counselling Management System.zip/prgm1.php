<html>
<head>
<script>
function validateR()
{
var selectedCombobox=(f2.type.value);
if(selectedCombobox=="2")
{
alert("please select the department");
return false;
}
var selectedCombobox=(f2.type1.value);
if(selectedCombobox=="3")
{
alert("please select the moi");
return false;
}
var selectedCombobox=(f2.type2.value);
if(selectedCombobox=="4")
{
alert("please select the community");
return false;
}
var selectedCombobox=(f2.type3.value);
if(selectedCombobox=="5")
{
alert("please select the department");
return false;
}
return true;
}
</script>
</head>
<title>counseling</title>
</head>
<body bgcolor=#efe4b0>

<center>
<pre>
<img src="images/logo1.jpg" width=80%>
<br>
<form name=f2  action="data.php"  method="post">

<font size=5  color="blue" face="Microsoft Sans Serif">
Application issue date:10.04.2018  &nbsp;&nbsp;&nbsp;&nbsp;  Application Receive Last date:15.05.2018</font>
<font size=6 color="brown" face="Ravie">
APPLICATION FORM</font><br><br>
<table width=100% border=0>
<tr align=right ><td>
<td allign=right><font size=4  color="red" face="Microsoft Sans Serif"><tdcolspan=2>*Mandatory field</tr>
<tr><td colspan=2 bgcolor=#40e0d0> <font size=5 color=black  face="Lucida Calligraphy"> BASIC DETAILS</tr> 

<tr bgcolor="lightblue">
<td width=50%><font size=5 color=black  face="Lucida Calligraphy">Mark Secured out of 1200
<td width=50%><input type="text" name="mark" 
ID="mark" required> 
<tr><td colspan=2 bgcolor=#40e0d0> <font size=5 color=black  face="Lucida Calligraphy"> Courses applied(In the order preference)</tr>
<table width=100% border=0>
<tr  bgcolor="lightblue">
<th><font size=5 color=black  face="Lucida Calligraphy">S.NO<th ><font size=5 color=black  face="Lucida Calligraphy">DEAPARTMENT<font size=5 color=black  face="Lucida Calligraphy"><th><font size=5 color=black  face="Lucida Calligraphy">MEDIUM OF INSTRUCTION </tr>
<tr ><td><font size=5 color=black  face="Lucida Calligraphy"> 1.
<td><font size=5 color=black  face="Lucida Calligraphy"> <select name="type" ><option value="2">--Not selected--</option>
<option>ECE</option>
<option>EEE</option><option >CSE</option>
<option>MECH</option>
</select>

<td><font size=5 color=black  face="Lucida Calligraphy">  
<select name="type1" ><option name="select" value="3">--select--</option>
<option>Tamil</option>
<option>English</option>

</select></tr>
<table width=100% border=0>
<tr><td colspan=2 bgcolor=#40e0d0> <font size=5 color=black  face="Lucida Calligraphy"> PERSONAL DETAILS</tr>
<tr>
<td bgcolor=lightblue width=50%><font size=5 color=black  face="Lucida Calligraphy">1.Name
<td width=50%><input type="text" name="name">  </tr>
<tr >
<td width=50% bgcolor=lightblue ><font size=5 color=black  face="Lucida Calligraphy">2.Gender
<td width=50%><input type="radio" name="gen" value="male" required> <font size=5 color=black  face="Lucida Calligraphy">Male &nbsp;&nbsp;&nbsp;
<input type="radio" name="gen" value="female" required> <font size=5 color=black  face="Lucida Calligraphy">Female &nbsp;&nbsp;&nbsp;
<input type="radio" name="gen"  value="Transgender"> <font size=5 color=black  face="Lucida Calligraphy">Transgender</tr>
<tr>
<td bgcolor=lightblue width=50%><font size=5 color=black  face="Lucida Calligraphy">3.Date of Birth
<td><font size=5 color=black  face="Lucida Calligraphy"> <input type="date" name="date" value="d1" min="2001-01-01" max="2001-12-31"required>(MM/DD/YY)</tr>
<tr>
<td bgcolor=lightblue width=50%><font size=5 color=black  face="Lucida Calligraphy">4.Community
<td><font size=5 color=black  face="Lucida Calligraphy"> <select name="type2"><option value="4">Select</option>
<option>0BC</option>
<option>MBC</option>
<option>ST/SC</option>
</select>
<tr>
<td bgcolor=lightblue width=50%><font size=5 color=black  face="Lucida Calligraphy">5.Nationality
<td width=50%><input type="text" name="national"required>  </tr>
<tr>
<td bgcolor=lightblue width=50%><font size=5 color=black  face="Lucida Calligraphy">6.Religion
<td width=50%><input type="text" name="religion"required>  </tr>
<tr>
<td bgcolor=lightblue width=50%><font size=5 color=black  face="Lucida Calligraphy">7.State
<td><font size=5 color=black  face="Lucida Calligraphy"> <select name="type3"> <option value="5">Select</option>
<option>Tamilnadu</option>
<option>Karnataka</option>
<option>Haryana</option>
<option>Delhi</option>
</select>
</tr>
<tr>
<td bgcolor=lightblue width=50%><font size=5 color=black  face="Lucida Calligraphy">8.Name of Father/Mother/Guardian
<td width=50%><input type="text" name="fmg"required>  </tr>
<tr>
<td bgcolor=lightblue width=50%><font size=5 color=black  face="Lucida Calligraphy">9.Annual Income
<td width=50%><input type="text" name="ai"required>  </tr>
<tr>
<td width=50% bgcolor=lightblue><font size=5 color=black  face="Lucida Calligraphy">10.If physically handicapped?Specify Certificate to be enclosed
<td width=50%><input type="radio" name="ph" value="yes"required> <font size=5 color=black  face="Lucida Calligraphy">YES &nbsp;&nbsp;&nbsp;<input type="radio" name="ph" value="no"required> <font size=5 color=black  face="Lucida Calligraphy">NO</tr>
<tr>
<td width=50% bgcolor=lightblue><font size=5 color=black  face="Lucida Calligraphy">11.Are you a Son/Daughter of Ex-Service man of Tamilnadu region?
<td width=50%><input type="radio" name="ex" value="yes"required> <font size=5 color=black  face="Lucida Calligraphy">YES &nbsp;&nbsp;&nbsp;<input type="radio" name="ex" value="no"required> <font size=5 color=black  face="Lucida Calligraphy">NO</tr>
<tr>
<td width=50% bgcolor=lightblue><font size=5 color=black  face="Lucida Calligraphy">12.Are you of Tamilnadu origin from Andaman Nicobar Islands?
<td width=50%><input type="radio" name="ani" value="yes"required> <font size=5 color=black  face="Lucida Calligraphy">YES &nbsp;&nbsp;&nbsp;<input type="radio" name="ani" value="no"required> <font size=5 color=black  face="Lucida Calligraphy">NO</tr>
<tr>
<td width=50% bgcolor=lightblue><font size=5 color=black  face="Lucida Calligraphy">13.Distinction in Sports/NCC/NSS
<td width=50%><input type="radio" name="snn"value="yes"required> <font size=5 color=black  face="Lucida Calligraphy">YES &nbsp;&nbsp;&nbsp;<input type="radio" name="snn" value="no"required> <font size=5 color=black  face="Lucida Calligraphy">NO</tr>
<tr>
<td width=50% bgcolor=lightblue><font size=5 color=black  face="Lucida Calligraphy">14.Address for Communication
<td width=50% rows=4 cols=20><textarea name="add" rows=4 cols=50 required> </textarea></tr>
<table width=100%  border=0>
<tr bgcolor=#40e0d0>
<th><font size=5 color=black  face="Lucida Calligraphy">SUBJECT
<th><font size=5 color=black  face="Lucida Calligraphy">MARKS SECURED
<th><font size=5 color=black  face="Lucida Calligraphy">MAXIMUM MARKS</tr>
<tr>
<td><font size=5 color=black  face="Lucida Calligraphy">Physics
<td  bgcolor=lightblue><input type="text" name="phy"required> 
<td><font size=5 color=black  face="Lucida Calligraphy">200
</tr>
<tr>
<td><font size=5 color=black  face="Lucida Calligraphy">Chemistry
<td bgcolor=lightblue ><input type="text" name="che"required> 
<td><font size=5 color=black  face="Lucida Calligraphy">200
</tr>
<tr>
<td><font size=5 color=black  face="Lucida Calligraphy">Mathematics
<td bgcolor=lightblue><input type="text" name="mat"required> 
<td><font size=5 color=black  face="Lucida Calligraphy">200
</tr>
<tr>
<td><font size=5 color=black  face="Lucida Calligraphy">Biology/Computer science
<td bgcolor=lightblue><input type="text" name="cs"required> 
<td><font size=5 color=black  face="Lucida Calligraphy">200
</tr>
</table>
<br>
<input type="submit" name="submit"  value="SUBMIT" onclick="return validateR();"><br>
<input type="submit" name="submit"  value="RESET"><br>
<a href="prgm.php"><img src="images/BACK.gif"><br>
</font></pre>
</centre>
</form>
</body>
</html>c
























